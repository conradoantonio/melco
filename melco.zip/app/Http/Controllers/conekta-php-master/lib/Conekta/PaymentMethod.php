<?php

namespace Conekta;

use \Conekta\Resource;

class PaymentMethod extends Resource
{
}
